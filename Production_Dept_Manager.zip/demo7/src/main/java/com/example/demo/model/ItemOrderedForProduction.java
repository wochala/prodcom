package com.example.demo.model;

import com.example.demo.model.Item;
import com.example.demo.model.ProductionOrder;

import javax.persistence.*;

@Entity
public class ItemOrderedForProduction {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    @ManyToOne(fetch = FetchType.EAGER)
    Item item;
    @ManyToOne(fetch = FetchType.EAGER)
    ProductionOrder productionOrder;
    private Integer qty;

    public ItemOrderedForProduction() {
    }

    public ItemOrderedForProduction(Integer id, Item item, ProductionOrder productionOrder, Integer qty) {
        this.id = id;
        this.item = item;
        this.productionOrder = productionOrder;
        this.qty = qty;
    }

    public ItemOrderedForProduction(Item item, ProductionOrder productionOrder, Integer qty) {
        this.item = item;
        this.productionOrder = productionOrder;
        this.qty = qty;
    }

    public Integer getQty() {
        return qty;
    }

    public void setQty(Integer qty) {
        this.qty = qty;
    }

    public Integer getId() {
        return id;
    }

    public Item getItem() {
        return item;
    }

    public void setItem(Item item) {
        this.item = item;
    }

    public ProductionOrder getProductionOrder() {
        return productionOrder;
    }

    public void setProductionOrder(ProductionOrder productionOrder) {
        this.productionOrder = productionOrder;
    }
}
