package com.example.demo.controller;

import com.example.demo.model.*;
import com.example.demo.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;

@Controller
public class BOMController {
    private ItemRepo itemRepo;
    private OrderRepo orderRepo;
    private OrderedItemRepo orderedItemRepo;
    private ItemOrderedForProductionRepo itemOrderedForProductionRepo;
    private TechnologyRepo technologyRepo;
    private BOMItemRepo bOMItemRepo;
    @Autowired
    public BOMController(TechnologyRepo technologyRepo, ItemRepo itemRepo, OrderRepo orderRepo, OrderedItemRepo orderedItemRepo, BOMItemRepo bOMItemRepo) {
        this.itemRepo = itemRepo;
        this.orderRepo = orderRepo;
        this.orderedItemRepo = orderedItemRepo;
        this.bOMItemRepo = bOMItemRepo;
        this.technologyRepo = technologyRepo;
    }


    @RequestMapping("/editBOM")
    public String editBOM(@RequestParam("technologyId") Integer technologyId,
                          Model model) {
        model.addAttribute("technologyId", technologyId);
        List<BOMItem> bOM = bOMItemRepo.findAllByTechnologyId(technologyId);
        model.addAttribute("bOM", bOM);
        return "editBOM";
    }

    @RequestMapping("/doAddBOMItem")
    public String doAddBOMItem(@RequestParam("technologyId") Integer technologyId,
                            @RequestParam("itemId") Integer itemId,
                            @RequestParam("qty") Integer qty,
                            Model model) {
        Technology technology=technologyRepo.findById(technologyId).get();
        Item item=itemRepo.findById(itemId).get();
        BOMItem bOMItem = new BOMItem(item, technology, qty);
        bOMItemRepo.save(bOMItem);
        return editBOM(technologyId, model);
    }

    @Transactional
    @RequestMapping("/deleteBOMItem")
    public String deleteBOMItem(@RequestParam("technologyId") Integer technologyId,
                            @RequestParam("itemId") Integer itemId,
                            Model model) {
        bOMItemRepo.deleteByTechnologyIdAndItemId(technologyId, itemId);
        return editBOM(technologyId, model);
    }
}


