package com.example.demo.model;

import javax.persistence.*;

@Entity
@Table(name="Technology")
public class Technology {


	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;
	private String description;
	@ManyToOne(cascade = CascadeType.ALL)
	private Item item;

	public Integer getId() {
		return id;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Item getItem() {
		return item;
	}

	public void setItem(Item item) {
		this.item = item;
	}

	public Technology() {
	}

	public Technology(String comments, Item item) {
		this.description = comments;
		this.item = item;
	}

	public Technology(Integer id, String comments, Item item) {
		this.id = id;
		this.description = comments;
		this.item = item;
	}
}
