package com.example.demo.model;

import org.springframework.format.annotation.DateTimeFormat;

import java.time.LocalDate;
import java.util.List;

import javax.persistence.*;

@Entity
@Table(name="Orders")
public class Order {

	public Order() {
		super();
	}

	public Order(String client, LocalDate dateOrdered, LocalDate deadline, String comments, String status) {
		this.client = client;
		this.dateOrdered = dateOrdered;
		this.deadline = deadline;
		this.comments = comments;
		this.status = status;
	}

	public Order(Integer id, String client, LocalDate dateOrdered, LocalDate deadline, String comments, String status) {
		this.id = id;
		this.client = client;
		this.dateOrdered = dateOrdered;
		this.deadline = deadline;
		this.comments = comments;
		this.status = status;
	}

	@Override
	public String toString() {
		return "Order{" +
				"id=" + id +
				", client='" + client + '\'' +
				", dateOrdered=" + dateOrdered +
				", deadline=" + deadline +
				", comments='" + comments + '\'' +
				", status=" + status +
				'}';
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getClient() {
		return client;
	}

	public void setClient(String client) {
		this.client = client;
	}

	public LocalDate getDateOrdered() {
		return dateOrdered;
	}

	public void setDateOrdered(LocalDate dateOrdered) {
		this.dateOrdered = dateOrdered;
	}

	public LocalDate getDeadline() {
		return deadline;
	}

	public void setDeadline(LocalDate deadline) {
		this.deadline = deadline;
	}

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}


	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;
	@Column(nullable = false)
	private String client;
	@DateTimeFormat(pattern="yyyy-MM-dd")
	private LocalDate dateOrdered;
	@DateTimeFormat(pattern="yyyy-MM-dd")
	private LocalDate deadline;
	private String comments;
	private String status;
	@OneToMany(mappedBy = "order", cascade = CascadeType.ALL)
	List<OrderedItem> orderedItems;

}
