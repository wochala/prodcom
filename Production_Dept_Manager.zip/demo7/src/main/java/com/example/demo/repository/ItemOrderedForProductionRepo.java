package com.example.demo.repository;

import com.example.demo.model.ItemOrderedForProduction;
import com.example.demo.model.ProductionOrder;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface ItemOrderedForProductionRepo extends JpaRepository <ItemOrderedForProduction, Integer> {
    List<ItemOrderedForProduction> findAllByProductionOrderId(Integer pOId);
    List<ItemOrderedForProduction> findAllByItemId(Integer itemId);
    void deleteAllByItem_IdAndProductionOrder_Id(Integer itemId, Integer pOId);


}