package com.example.demo.controller;

import com.example.demo.model.Item;
import com.example.demo.model.ItemOrderedForProduction;
import com.example.demo.model.ProductionOrder;
import com.example.demo.repository.ItemOrderedForProductionRepo;
import com.example.demo.repository.ItemRepo;
import com.example.demo.repository.ProductionOrderRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;

@Controller
public class IOPLController {
    private ItemRepo itemRepo;
    private ProductionOrderRepo productionOrderRepo;
    private ItemOrderedForProductionRepo itemOrderedForProductionRepo;
    @Autowired
    public IOPLController(ItemRepo itemRepo, ProductionOrderRepo productionOrderRepo, ItemOrderedForProductionRepo itemOrderedForProductionRepo) {
        this.itemRepo = itemRepo;
        this.productionOrderRepo = productionOrderRepo;
        this.itemOrderedForProductionRepo = itemOrderedForProductionRepo;
    }

    @RequestMapping("/editIOPL")
    public String editIOPL(@RequestParam("pOId") Integer pOId,
                         Model model) {
        List<ItemOrderedForProduction> iOPL = itemOrderedForProductionRepo.findAllByProductionOrderId(pOId);
        model.addAttribute("pOId", pOId);
        model.addAttribute("iOPL", iOPL);
        return "editIOPL";
    }

    @RequestMapping("/doAddIOP")
    public String doAddIOP(@RequestParam("pOId") Integer pOId,
                           @RequestParam("itemId") Integer itemId,
                           @RequestParam("qty") Integer qty,
                           Model model) {
        Item item=itemRepo.findById(itemId).get();
        ProductionOrder productionOrder=productionOrderRepo.findById(pOId).get();
        ItemOrderedForProduction itemOrderedForProduction=new ItemOrderedForProduction(item, productionOrder, qty);
        itemOrderedForProductionRepo.save(itemOrderedForProduction);
        return editIOPL(pOId, model);
    }

    @Transactional
    @RequestMapping("/deleteIOP")
    public String editOIL(@RequestParam("pOId") Integer pOId,
                          @RequestParam("itemId") Integer itemId,
                          Model model){
        Item item=itemRepo.findById(itemId).get();
        ProductionOrder productionOrder=productionOrderRepo.findById(pOId).get();
        itemOrderedForProductionRepo.deleteAllByItem_IdAndProductionOrder_Id(itemId, pOId);
        model.addAttribute("pOId", pOId);
        return editIOPL(pOId, model);
    }}
