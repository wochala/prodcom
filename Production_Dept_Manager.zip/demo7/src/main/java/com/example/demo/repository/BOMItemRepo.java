package com.example.demo.repository;

import com.example.demo.model.BOMItem;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface BOMItemRepo extends JpaRepository <BOMItem, Integer> {
    List<BOMItem> findAllByTechnologyId(Integer technologyId);
    List<BOMItem> findAllByItemId(Integer itemId);
    void deleteByTechnologyIdAndItemId(Integer technologyId, Integer itemId);
}
