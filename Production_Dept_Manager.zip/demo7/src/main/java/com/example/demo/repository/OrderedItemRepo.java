package com.example.demo.repository;

import com.example.demo.model.OrderedItem;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;


public interface OrderedItemRepo extends JpaRepository<OrderedItem, Integer> {
    List<OrderedItem> findAllByorderId(Integer query);
    List<OrderedItem> findAllByitemId(Integer query);
    long deleteAllByItem_IdAndOrder_Id(Integer item, Integer order);

}
