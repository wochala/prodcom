package com.example.demo.model;
import javax.persistence.*;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import java.util.List;

@Entity
public class Item {
    public Item() {
        super();
    }
    @Override
    public String toString() {
        return "Item{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", description='" + description + '\'' +
                ", supplier='" + supplier + '\'' +
                ", qty=" + qty +
                ", unit='" + unit + '\'' +
                '}';
    }

    public Item(Integer id, String name, String description, String supplier, int qty, String unit) {
        super();
        this.id=id;
        this.name = name;
        this.description = description;
        this.supplier = supplier;
        this.qty = qty;
        this.unit = unit;
    }

    public Item(String name, String description, String supplier, int qty, String unit) {
        super();
        this.name = name;
        this.description = description;
        this.supplier = supplier;
        this.qty = qty;
        this.unit = unit;
    }
    public Integer getId() {
        return id;
    }
    public void setId(Integer id) {
        this.id = id;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public String getDescription() {
        return description;
    }
    public void setDescription(String description) {
        this.description = description;
    }
    public String getSupplier() {
        return supplier;
    }
    public void setSupplier(String supplier) {
        this.supplier = supplier;
    }
    public int getQty() {
        return qty;
    }
    public void setQty(int qty) {
        this.qty = qty;
    }
    public String getUnit() {
        return unit;
    }
    public void setUnit(String unit) {
        this.unit = unit;
    }
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    @Column(nullable=false)
    private String name;
    @NotEmpty(message = "User's email cannot be empty.")
    @NotNull(message = "User's email cannot be empty.")
    private String description;
    @NotEmpty(message = "User's email cannot be empty.")
    private String supplier;
    private int qty;
    private String unit;
    @OneToMany(mappedBy = "item", cascade = CascadeType.ALL)
    List<BOMItem> bomItems;
    @OneToMany(mappedBy = "item", cascade = CascadeType.ALL)
    List<ItemOrderedForProduction> iOPL;
    @OneToMany(mappedBy = "item", cascade = CascadeType.ALL)
    List<OrderedItem> orderedItems;
    @OneToMany(mappedBy = "item", cascade = CascadeType.ALL)
    List<Technology> technologies;
}
