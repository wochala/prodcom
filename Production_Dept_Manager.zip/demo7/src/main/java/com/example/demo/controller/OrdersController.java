package com.example.demo.controller;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;

import com.example.demo.model.Item;
import com.example.demo.model.OrderedItem;
import com.example.demo.repository.OrderRepo;
import com.example.demo.model.Order;
import com.example.demo.repository.ItemRepo;
import com.example.demo.repository.OrderedItemRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
@Controller
public class OrdersController {
    private final ItemRepo itemRepo;
    private final OrderRepo orderRepo;
    private final OrderedItemRepo orderedItemRepo;
    @Autowired
    public OrdersController(ItemRepo itemRepo, OrderRepo orderRepo, OrderedItemRepo orderedItemRepo) {
        this.itemRepo = itemRepo;
        this.orderRepo = orderRepo;
        this.orderedItemRepo = orderedItemRepo;
    }

    @RequestMapping("/addOrder")
    public String addOrder(){
        return "addOrder";
    }

    @RequestMapping("/doAddOrder")
    public String doAddOrder(
            @RequestParam("client") String client,
            @RequestParam("comments") String comments,
            @RequestParam("status") String status,
            @RequestParam("dateOrdered") String dateOrdered,
            @RequestParam("deadline") String deadline,
            Model model)
            throws Exception {
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        LocalDate ldDateOrdered = LocalDate.parse(dateOrdered, dtf);
        LocalDate ldDeadline = LocalDate.parse(deadline, dtf);
        Order order = new Order(client, ldDateOrdered, ldDeadline, comments, status);
        orderRepo.save(order); // ZAPIS DO BAZY !!!!
        return showOrders(model);
    }

    @RequestMapping("/orders")
    public String showOrders(Model model){
        LocalDate now=LocalDate.now();
        model.addAttribute("orders", orderRepo.findAll());
        model.addAttribute("now", now);
        return "orders";
    }

    @RequestMapping("/deleteOrder")
    public String deleteOrder(@RequestParam("id") Integer id, Model model){
        orderRepo.deleteById(id);
        return showOrders(model);
    }

    @RequestMapping("editOrder")
    public String editOrder(@RequestParam("id") Integer id, Model model){
        Order order=orderRepo.findById(id).get();
        model.addAttribute("order", order);
        return "editOrder";
    }


    @RequestMapping("/doEditOrder")
    public String doEditOrder(
            @RequestParam("id") Integer id,
            @RequestParam("client") String client,
            @RequestParam("comments") String comments,
            @RequestParam("status") String status,
            @RequestParam("dateOrdered") String dateOrdered,
            @RequestParam("deadline") String deadline,
            Model model)
            throws Exception {

        if(status.equals("sent")){
            List<OrderedItem> oIL=orderedItemRepo.findAllByorderId(id);
            for(OrderedItem oI: oIL) {
                Item i = itemRepo.findById(oI.getItem().getId()).get();
                i.setQty(i.getQty()-oI.getQty());
                itemRepo.save(i);
            }
        }
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        LocalDate ldDateOrdered = LocalDate.parse(dateOrdered, dtf);
        LocalDate ldDeadline = LocalDate.parse(deadline, dtf);
        Order order = new Order(id, client, ldDateOrdered, ldDeadline, comments, status); //podajemy id, aby doszło do nadpisania
        orderRepo.save(order); // ZAPIS DO BAZY !!!!
        return showOrders(model);
    }

    @RequestMapping("/findOrders")
    public String search(@RequestParam("query") String query, Model model) throws Exception{
        LocalDate now=LocalDate.now();
        model.addAttribute("orders", orderRepo.findAllByClientContainingIgnoreCase(query));
        model.addAttribute("now", now);
        return "orders";
    }

}


