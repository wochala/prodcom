package com.example.demo.model;

public class ItemInfo {
    private Item item;
    public int prognosedQty;

    public Item getItem() {
        return item;
    }

    public void setItem(Item item) {
        this.item = item;
    }

    public int getPrognosedQty() {
        return prognosedQty;
    }

    public void setPrognosedQty(int prognosedQty) {
        this.prognosedQty = prognosedQty;
    }

    public ItemInfo(Item item, int prognosedQty) {
        this.item = item;
        this.prognosedQty = prognosedQty;
    }

    @Override
    public String toString() {
        return "PrognosedQuantity{" +
                "item=" + item +
                ", prognosedQty=" + prognosedQty +
                '}';
    }
}
