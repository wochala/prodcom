package com.example.demo.controller;

import com.example.demo.model.Item;
import com.example.demo.model.ItemOrderedForProduction;
import com.example.demo.model.Order;
import com.example.demo.model.ProductionOrder;
import com.example.demo.repository.ItemOrderedForProductionRepo;
import com.example.demo.repository.ItemRepo;
import com.example.demo.repository.ProductionOrderRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;

@Controller
public class ProductionController {
    private ItemRepo itemRepo;
    private ProductionOrderRepo productionOrderRepo;
    private ItemOrderedForProductionRepo itemOrderedForProductionRepo;
    @Autowired
    public ProductionController(ItemRepo itemRepo, ProductionOrderRepo productionOrderRepo, ItemOrderedForProductionRepo itemOrderedForProductionRepo) {
        this.itemRepo = itemRepo;
        this.productionOrderRepo = productionOrderRepo;
        this.itemOrderedForProductionRepo = itemOrderedForProductionRepo;
    }

    @RequestMapping("/findPO")
    public String search(@RequestParam("query") String query, Model model) throws Exception{
        model.addAttribute("productionOrders", productionOrderRepo.findAllByCommentsContainingIgnoreCase(query));
        return "production";
    }

    @RequestMapping("/production")
    public String showProduction(Model model){
        List<ProductionOrder> productionOrders=productionOrderRepo.findAll();
        LocalDate now=LocalDate.now();
        model.addAttribute("now", LocalDate.now());
        model.addAttribute("productionOrders", productionOrders);
        return "production";
    }

    @RequestMapping("/editPO")
    public String editPO(@RequestParam("pOId") Integer pOId,
                         Model model) {
        ProductionOrder productionOrder = productionOrderRepo.findById(pOId).get();
        model.addAttribute("pOId", pOId);
        model.addAttribute("productionOrder", productionOrder);
        return "editPO";
    }

    @RequestMapping("/doEditPO")
    public String doEditPO(@RequestParam("pOId") Integer pOId,
                           @RequestParam("comments") String comments,
                           @RequestParam("dateIssued") String dateOrdered,
                           @RequestParam("deadline") String deadline,
                           @RequestParam("status") String status,
                           Model model) {
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        LocalDate ldDateOrdered = LocalDate.parse(dateOrdered, dtf);
        LocalDate ldDeadline = LocalDate.parse(deadline, dtf);
        ProductionOrder productionOrder=new ProductionOrder(pOId, comments, ldDateOrdered, ldDeadline, status);
        productionOrderRepo.save(productionOrder);
        return showProduction(model);
    }

    @RequestMapping("/deletePO")
    public String addPO(@RequestParam("pOId") Integer pOId, Model model) {
    productionOrderRepo.deleteById(pOId);
    return showProduction(model);
    }

    @RequestMapping("/addPO")
    public String addPO(Model model) {
        return "addPO";
    }

    @RequestMapping("/doAddPO")
    public String doAddProductionOrder(@RequestParam("comments") String comments,
                                       @RequestParam("dateOrdered") String dateOrdered,
                                       @RequestParam("deadline") String deadline,
                                       @RequestParam("status") String status,
                                       Model model) {
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        LocalDate ldDateOrdered = LocalDate.parse(dateOrdered, dtf);
        LocalDate ldDeadline = LocalDate.parse(deadline, dtf);
        ProductionOrder productionOrder=new ProductionOrder(comments, ldDateOrdered, ldDeadline, status);
        productionOrderRepo.save(productionOrder);
        return showProduction(model);
    }
}
