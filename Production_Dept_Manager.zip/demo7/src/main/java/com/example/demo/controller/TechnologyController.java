package com.example.demo.controller;

import com.example.demo.model.Item;
import com.example.demo.model.ItemOrderedForProduction;
import com.example.demo.model.ProductionOrder;
import com.example.demo.model.Technology;
import com.example.demo.repository.ItemOrderedForProductionRepo;
import com.example.demo.repository.ItemRepo;
import com.example.demo.repository.ProductionOrderRepo;
import com.example.demo.repository.TechnologyRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;

@Controller
public class TechnologyController {
    private ItemRepo itemRepo;
    private ProductionOrderRepo productionOrderRepo;
    private ItemOrderedForProductionRepo itemOrderedForProductionRepo;
    private TechnologyRepo technologyRepo;
    @Autowired
    public TechnologyController(ItemRepo itemRepo, ProductionOrderRepo productionOrderRepo, ItemOrderedForProductionRepo itemOrderedForProductionRepo, TechnologyRepo technologyRepo) {
        this.itemRepo = itemRepo;
        this.productionOrderRepo = productionOrderRepo;
        this.itemOrderedForProductionRepo = itemOrderedForProductionRepo;
        this.technologyRepo = technologyRepo;
    }

    @RequestMapping("/findTechnology")
    public String search(@RequestParam("query") String query, Model model) throws Exception{
        model.addAttribute("technologies", technologyRepo.findAllByItemNameContainingIgnoreCase(query));
        return "technology";
    }

    @RequestMapping("/technology")
    public String showTechnology(Model model){
        List<Technology> technologies=technologyRepo.findAll();
        model.addAttribute("technologies", technologies);
        return "technology";
    }

    @RequestMapping("/editTechnology")
    public String editTechnology(@RequestParam("technologyId") Integer technologyId,
                         Model model) {
        Technology technology=technologyRepo.findById(technologyId).get();
        model.addAttribute("technology", technology);
        return "editTechnology";
    }
    @RequestMapping("/doEditTechnology")
    public String doEditTechnology(@RequestParam("technologyId") Integer technologyId,
                                   @RequestParam("description") String description,
                                   Model model) {
        Item item=technologyRepo.findById(technologyId).get().getItem();
        Technology technology=new Technology(technologyId, description, item);
        technologyRepo.save(technology);
        model.addAttribute("technology", technology);
        return showTechnology(model);
    }

    @RequestMapping("/deleteTechnology")
    public String deleteTechnology(@RequestParam("technologyId") Integer technologyId, Model model) {
    technologyRepo.deleteById(technologyId);
    return showTechnology(model);
    }

    @RequestMapping("/addTechnology")
    public String addTechnology(Model model) {
        return "addTechnology";
    }

    @RequestMapping("/doAddTechnology")
    public String doAddProductionOrder(@RequestParam("itemId") Integer itemId,
                                       @RequestParam("description") String description,
                                       Model model) {
        Item item=itemRepo.findById(itemId).get();
        Technology technology=new Technology(description, item);
        technologyRepo.save(technology);
        return showTechnology(model);
    }

}
