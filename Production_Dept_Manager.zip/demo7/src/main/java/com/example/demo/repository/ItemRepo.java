package com.example.demo.repository;

import java.util.List;

import com.example.demo.model.Item;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ItemRepo extends JpaRepository <Item, Integer> {
	List<Item> findAllByname(String query); //nazwa funkcji ma znaczenie - String skojarzy ją sobie z polem name!
	List<Item> findAllBynameAndDescription(String name, String Name);
}
