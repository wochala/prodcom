package com.example.demo.model;

import javax.persistence.*;

@Entity
public class BOMItem {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    Integer id;
    @ManyToOne(fetch = FetchType.EAGER)
    private Item item;
    @ManyToOne(fetch = FetchType.EAGER)
    private Technology technology;
    private Integer qty;

    public Integer getId() {
        return id;
    }

    public Item getItem() {
        return item;
    }

    public void setItem(Item item) {
        this.item = item;
    }

    public Technology getTechnology() {
        return technology;
    }

    public void setTechnology(Technology technology) {
        this.technology = technology;
    }

    public Integer getQty() {
        return qty;
    }

    public void setQty(Integer qty) {
        this.qty = qty;
    }

    public BOMItem(Integer id, Item item, Technology technology, Integer qty) {
        this.id = id;
        this.item = item;
        this.technology = technology;
        this.qty = qty;
    }

    public BOMItem() {
    }

    public BOMItem(Item item, Technology technology, Integer qty) {
        this.item = item;
        this.technology = technology;
        this.qty = qty;
    }
}
