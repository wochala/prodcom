package com.example.demo.repository;

import com.example.demo.model.ProductionOrder;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface ProductionOrderRepo extends JpaRepository <ProductionOrder, Integer> {
    List<ProductionOrder> findAllByCommentsContainingIgnoreCase(String query);
}
