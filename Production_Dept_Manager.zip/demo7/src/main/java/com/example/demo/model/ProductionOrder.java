package com.example.demo.model;

import javax.persistence.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

@Entity
public class ProductionOrder {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    private String comments;
    private LocalDate dateIssued;
    private LocalDate deadline;
    private String status;
    @OneToMany(mappedBy = "productionOrder", cascade = CascadeType.ALL)
    List<ItemOrderedForProduction> iOPL;

    public ProductionOrder() {
    }

    public ProductionOrder(String comments, LocalDate dateIssued, LocalDate deadline, String status) {
        this.comments = comments;
        this.dateIssued = dateIssued;
        this.deadline = deadline;
        this.status = status;
    }

    public ProductionOrder(Integer id, String comments, LocalDate dateIssued, LocalDate deadline, String status) {
        this.id = id;
        this.comments = comments;
        this.dateIssued = dateIssued;
        this.deadline = deadline;
        this.status = status;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getComments() {
        return comments;
    }

    public void setComments(String comments) {
        this.comments = comments;
    }

    public LocalDate getDateIssued() {
        return dateIssued;
    }

    public void setDateIssued(LocalDate dateIssued) {
        this.dateIssued = dateIssued;
    }

    public LocalDate getDeadline() {
        return deadline;
    }

    public void setDeadline(LocalDate deadline) {
        this.deadline = deadline;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
