package com.example.demo.controller;

import com.example.demo.repository.OrderRepo;
import com.example.demo.model.Item;
import com.example.demo.model.Order;
import com.example.demo.model.OrderedItem;
import com.example.demo.repository.ItemRepo;
import com.example.demo.repository.OrderedItemRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class OILController {
    private ItemRepo itemRepo;
    private OrderRepo orderRepo;
    private OrderedItemRepo orderedItemRepo;
    @Autowired
    public OILController(ItemRepo itemRepo, OrderRepo orderRepo, OrderedItemRepo orderedItemRepo) {
        this.itemRepo = itemRepo;
        this.orderRepo = orderRepo;
        this.orderedItemRepo = orderedItemRepo;
    }

    @RequestMapping("/doAddOI")
    public String doAddOI(
            @RequestParam("orderId") Integer orderId,
            @RequestParam("itemId") Integer itemId,
            @RequestParam("qty") Integer qty, Model model)
            throws Exception {
        Order order= orderRepo.findById(orderId).get();
        Item item=itemRepo.findById(itemId).get();
        System.out.println("doAddOI activated");
        OrderedItem orderedItem=new OrderedItem(item, order, qty);
        //System.out.println(item);
        //System.out.println(order);
        //System.out.println(orderedItem);
        orderedItemRepo.save(orderedItem);
        return editOIL(orderId, model);
    }

    @RequestMapping("/editOIL")
    public String editOIL(@RequestParam("orderId") Integer orderId, Model model){
        model.addAttribute("orderId", orderId);
        model.addAttribute("orderedItems", orderedItemRepo.findAllByorderId(orderId));
        return "editOIL";
    }

    @RequestMapping("/browseItems")
    public String browseItems(@RequestParam("orderId") Integer orderId, Model model){
        model.addAttribute("orderId", orderId);
        model.addAttribute("items", itemRepo.findAll());
        return "browseItems";
    }

    @Transactional
    @RequestMapping("/deleteOI")
    public String editOIL(@RequestParam("orderId") Integer orderId,
                          @RequestParam("itemId") Integer itemId,
                          Model model){
        orderedItemRepo.deleteAllByItem_IdAndOrder_Id(itemId, orderId);
        model.addAttribute("orderId", orderId);
        return editOIL(orderId, model);
    }
}


