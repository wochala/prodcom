package com.example.demo.controller;

import com.example.demo.model.*;
import com.example.demo.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import javax.validation.Valid;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

@Controller
public class WarehouseController {
    private ItemRepo itemRepo;
    private OrderedItemRepo orderedItemRepo;
    private ItemOrderedForProductionRepo itemOrderedForProductionRepo;
    private BOMItemRepo bOMItemRepo;
    private ProductionOrderRepo productionOrderRepo;
    private TechnologyRepo technologyRepo;
    @Autowired
    public WarehouseController(ItemRepo itemRepo, OrderedItemRepo orderedItemRepo, ItemOrderedForProductionRepo itemOrderedForProductionRepo, BOMItemRepo bOMItemRepo, ProductionOrderRepo productionOrderRepo, TechnologyRepo technologyRepo) {
        this.itemRepo = itemRepo;
        this.orderedItemRepo = orderedItemRepo;
        this.itemOrderedForProductionRepo=itemOrderedForProductionRepo;
        this.bOMItemRepo=bOMItemRepo;
        this.productionOrderRepo=productionOrderRepo;
        this.technologyRepo=technologyRepo;
    }

    @RequestMapping("/")
    public String home(Model model)
            throws Exception {
        return showWarehouse(model);

    }

    @RequestMapping("/doAddItem")
    public String adding(
            @Valid Item item,
            BindingResult result,
            Model model)
            throws Exception {
        if (result.hasErrors()) {
            return "addItem";
        }
        Item it = new Item(item.getName(), item.getDescription(), item.getSupplier(), item.getQty(), item.getUnit());
        System.out.println("add");
        System.out.println(it);
        itemRepo.save(it); // ZAPIS DO BAZY !!!!
        return showWarehouse(model);
    }

    @RequestMapping("/addItem")
    public String addItem(Item item){
        System.out.println("addItem");
        return "addItem";
    }

    @RequestMapping("/deleteItem")
    public String kasuj(@RequestParam("id") Integer id, Model model) throws Exception{
        itemRepo.deleteById(id);
        model.addAttribute("items", itemRepo.findAll());
        return showWarehouse(model);
    }

    @RequestMapping("/editItem")
    public String edit(
            @RequestParam("id") Integer id, Model model
    )
            throws Exception {
        System.out.println(itemRepo.findById(id));
        model.addAttribute("item", itemRepo.findById(id));
        return "editItem";
    }

    @RequestMapping("/warehouse")
    public String showWarehouse(Model model)
            throws Exception {
        List<Item> itemsList=itemRepo.findAll();
        Collections.sort(itemsList, (Item i1, Item i2)->{return i1.getQty()-i2.getQty();});
        //this list will hold the information of projected quantity per each item:
        List<ItemInfo> itemsInfo=new ArrayList<ItemInfo>();
        for(Item i:itemsList){ //for all items
            //...we check if they are ordered:
            List<OrderedItem> orderedItemsList=orderedItemRepo.findAllByitemId(i.getId());
            int q=i.getQty(); //(we'll use q to calculate projected quantity)
            for(OrderedItem o: orderedItemsList){ //for all what is ordered
                if(o.getOrder().getStatus().equals("confirmed")||o.getOrder().getStatus().equals("inProgress")){
                    q-=o.getQty(); //...we decrease q
                }
            }
            //next we check if they're ordered for production
            List<ItemOrderedForProduction> iOPL= itemOrderedForProductionRepo.findAllByItemId(i.getId());
            for(ItemOrderedForProduction iop:iOPL){ //for all what is ordered
                if(iop.getProductionOrder().getStatus().equals("confirmed")||iop.getProductionOrder().getStatus().equals("inProgress")){
                    q+=iop.getQty(); //...we increase q
                }
            }
            //finally (for each item) we create an object, that will hold the value of q:
            ItemInfo itemInfo =new ItemInfo(i,q);
            itemsInfo.add(itemInfo); //...and add it to our list
        }
        //List<ProductionOrder> productionOrders=productionOrderRepo.findAll();
        List<ItemOrderedForProduction> iopl=itemOrderedForProductionRepo.findAll();
        for(ItemOrderedForProduction iop:iopl){ //for all, what is ordered for production
            //we need to know the technology:
            Technology tech=technologyRepo.findByItemId(iop.getItem().getId());
            //so that we can check the bill of materials:
            List<BOMItem> bOM=bOMItemRepo.findAllByTechnologyId(tech.getId());
            for(BOMItem bi:bOM){ //now for all items that are part of bill of materials
                //we find an object which holds the value of q for that item:
                ItemInfo ii = itemsInfo.stream()
                        .filter(x -> x.getItem().getId()==bi.getItem().getId())
                        .findFirst()
                        .get();
                //...and decrease the value of q for that item:
                ii.setPrognosedQty(ii.getPrognosedQty()-bi.getQty()*iop.getQty());
            }
        }
        model.addAttribute("itemsInfo", itemsInfo);
        return "warehouse";
    }

    @RequestMapping("/doEditItem")
    public String update(
            @RequestParam("id") Integer id,
            @RequestParam("name") String name,
            @RequestParam("description") String description,
            @RequestParam("supplier") String supplier,
            @RequestParam("qty") int qty,
            @RequestParam("unit") String unit, Model model)
            throws Exception {
        Item newItem = new Item(id, name, description, supplier, qty, unit);
        System.out.println(newItem);
        itemRepo.save(newItem);
        return showWarehouse(model);
        }

}
