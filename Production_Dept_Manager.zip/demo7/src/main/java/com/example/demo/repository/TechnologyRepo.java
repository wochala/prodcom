package com.example.demo.repository;

import com.example.demo.model.Technology;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface TechnologyRepo extends JpaRepository <Technology, Integer> {
    Technology findByItemId(Integer itemId);
    List<Technology> findAllByItemNameContainingIgnoreCase(String query);
}
